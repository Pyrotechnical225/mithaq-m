import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import {
  createImam,
  deleteImam,
  listAllImamsAdmin,
  seedExampleImams,
  updateImam,
  ADMIN_UK_CITIES,
} from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin/imams")({
  head: () => ({ meta: [{ title: "Imams — Admin" }, { name: "robots", content: "noindex" }] }),
  component: ImamsAdmin,
});

type Imam = Awaited<ReturnType<typeof listAllImamsAdmin>>[number];

function ImamsAdmin() {
  const fetchAll = useServerFn(listAllImamsAdmin);
  const doCreate = useServerFn(createImam);
  const doUpdate = useServerFn(updateImam);
  const doDelete = useServerFn(deleteImam);
  const doSeed = useServerFn(seedExampleImams);

  const [rows, setRows] = useState<Imam[] | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [editing, setEditing] = useState<Imam | null>(null);
  const empty = {
    name: "",
    title: "Imam",
    mosque: "",
    city: ADMIN_UK_CITIES[0],
    postcode: "",
    phone: "",
    email: "",
    website: "",
    languages: "",
    notes: "",
    verification_status: "pending" as "pending" | "verified" | "suspended",
  };
  const [form, setForm] = useState(empty);

  const load = () => fetchAll().then(setRows);
  useEffect(() => {
    load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    const payload = {
      name: form.name.trim(),
      title: form.title.trim() || null,
      mosque: form.mosque.trim() || null,
      city: form.city.trim(),
      postcode: form.postcode.trim() || null,
      phone: form.phone.trim() || null,
      email: form.email.trim() || null,
      website: form.website.trim() || null,
      languages: form.languages
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
      notes: form.notes.trim() || null,
      verification_status: form.verification_status,
    };
    try {
      if (editing) {
        await doUpdate({ data: { id: editing.id, ...payload } });
        setMsg("Updated.");
      } else {
        await doCreate({ data: payload });
        setMsg("Created.");
      }
      setForm(empty);
      setEditing(null);
      load();
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "Failed");
    }
  };

  const edit = (r: Imam) => {
    setEditing(r);
    setForm({
      name: r.name ?? "",
      title: r.title ?? "",
      mosque: r.mosque ?? "",
      city: r.city ?? ADMIN_UK_CITIES[0],
      postcode: r.postcode ?? "",
      phone: r.phone ?? "",
      email: r.email ?? "",
      website: r.website ?? "",
      languages: (r.languages ?? []).join(", "),
      notes: r.notes ?? "",
      verification_status: r.verification_status as "pending" | "verified" | "suspended",
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this imam?")) return;
    await doDelete({ data: { id } });
    load();
  };

  const seed = async () => {
    const r = await doSeed();
    setMsg(`Seeded ${r.inserted} example imam(s); ${r.skipped} already existed.`);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <h1 className="text-3xl text-foreground">Imams directory</h1>
        <button
          onClick={seed}
          className="rounded-full border border-border px-3 py-1.5 text-xs hover:bg-accent"
        >
          Seed example imams
        </button>
      </div>

      <form
        onSubmit={submit}
        className="grid gap-3 rounded-2xl border border-border bg-card p-6 md:grid-cols-2"
      >
        <h2 className="md:col-span-2 text-sm uppercase tracking-widest text-muted-foreground">
          {editing ? `Editing ${editing.name}` : "Add a new imam"}
        </h2>
        <Field
          label="Name"
          value={form.name}
          onChange={(v) => setForm({ ...form, name: v })}
          required
        />
        <label className="block">
          <span className="text-xs uppercase tracking-widest text-muted-foreground">
            Verification
          </span>
          <select
            value={form.verification_status}
            onChange={(event) =>
              setForm({
                ...form,
                verification_status: event.target.value as typeof form.verification_status,
              })
            }
            className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
          >
            <option value="pending">Pending review</option>
            <option value="verified">Verified</option>
            <option value="suspended">Suspended</option>
          </select>
        </label>
        <Field label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} />
        <Field
          label="Mosque"
          value={form.mosque}
          onChange={(v) => setForm({ ...form, mosque: v })}
        />
        <label className="block">
          <span className="text-xs uppercase tracking-widest text-muted-foreground">City</span>
          <select
            value={form.city}
            onChange={(e) => setForm({ ...form, city: e.target.value })}
            className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
          >
            {ADMIN_UK_CITIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
        <Field
          label="Postcode"
          value={form.postcode}
          onChange={(v) => setForm({ ...form, postcode: v })}
        />
        <Field label="Phone" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} />
        <Field label="Email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
        <Field
          label="Website"
          value={form.website}
          onChange={(v) => setForm({ ...form, website: v })}
        />
        <Field
          label="Languages (comma-separated)"
          value={form.languages}
          onChange={(v) => setForm({ ...form, languages: v })}
        />
        <label className="md:col-span-2 block">
          <span className="text-xs uppercase tracking-widest text-muted-foreground">Notes</span>
          <textarea
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            rows={2}
            className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
          />
        </label>
        {msg && <p className="md:col-span-2 text-sm text-muted-foreground">{msg}</p>}
        <div className="md:col-span-2 flex gap-2">
          <button className="rounded-full bg-primary px-5 py-2 text-sm text-primary-foreground hover:bg-primary/90">
            {editing ? "Save changes" : "Add imam"}
          </button>
          {editing && (
            <button
              type="button"
              onClick={() => {
                setEditing(null);
                setForm(empty);
              }}
              className="rounded-full border border-border px-4 py-2 text-sm hover:bg-accent"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      <div className="overflow-x-auto rounded-2xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted text-left text-xs uppercase tracking-widest text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Mosque</th>
              <th className="px-4 py-3">City</th>
              <th className="px-4 py-3">Contact</th>
              <th className="px-4 py-3">Languages</th>
              <th className="px-4 py-3">Verification</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {(rows ?? []).map((r) => (
              <tr key={r.id} className="hover:bg-accent/40">
                <td className="px-4 py-3 text-foreground">
                  <div className="font-medium">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.title}</div>
                </td>
                <td className="px-4 py-3 text-foreground">{r.mosque ?? "—"}</td>
                <td className="px-4 py-3 text-foreground">
                  {r.city}
                  {r.postcode ? `, ${r.postcode}` : ""}
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">
                  {r.phone && <div>{r.phone}</div>}
                  {r.email && <div>{r.email}</div>}
                </td>
                <td className="px-4 py-3 text-xs">{(r.languages ?? []).join(", ")}</td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded-full px-2.5 py-1 text-xs font-medium ${
                      r.verification_status === "verified"
                        ? "bg-primary/10 text-primary"
                        : r.verification_status === "suspended"
                          ? "bg-destructive/10 text-destructive"
                          : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {r.verification_status}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <button
                      onClick={() => edit(r)}
                      className="rounded-full border border-border px-3 py-1 text-xs hover:bg-accent"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => remove(r.id)}
                      className="rounded-full border border-destructive/40 px-3 py-1 text-xs text-destructive hover:bg-destructive/10"
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {rows && rows.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">
                  No imams yet. Add one above or seed examples.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-widest text-muted-foreground">{label}</span>
      <input
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
      />
    </label>
  );
}
