# ChatGPT changes

## UI and mobile
- Added a responsive mobile navigation menu to the public site header.
- Added a responsive mobile navigation menu to the admin area.
- Rebuilt the admin Imams page with mobile cards, desktop table, larger touch targets, clearer status summaries and improved forms.
- Added reusable, accessible form-control styling and mobile interaction improvements.

## Imam account management
- Admins can create an authentication account for an existing imam directory profile.
- Admins can set an initial temporary password and coverage radius.
- Admins can reset an imam password later.
- Existing passwords are never shown or stored in readable form. A reset replaces the old password.
- The admin list shows login email, active status and last sign-in date.

## Important
The build could not be run in the ChatGPT environment because its package registry did not contain `@ai-sdk/openai-compatible`. Run `npm install` and `npm run build` in GitHub Codespaces, locally, or through Lovable after syncing.
