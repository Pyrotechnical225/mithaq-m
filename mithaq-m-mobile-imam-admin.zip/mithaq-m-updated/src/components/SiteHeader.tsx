import { Link } from "@tanstack/react-router";
import { ChevronDown, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

const learnLinks = [
  { to: "/nikah", label: "Nikah" },
  { to: "/halal-relationships", label: "Halal relationships" },
  { to: "/mahr", label: "Mahr" },
  { to: "/wali", label: "Wali" },
  { to: "/community", label: "Community" },
] as const;

export function SiteHeader() {
  const [signedIn, setSignedIn] = useState(false);
  const [verified, setVerified] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [learnOpen, setLearnOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const refresh = async () => {
    const { data } = await supabase.auth.getUser();
    const user = data.user;
    setSignedIn(!!user);
    setVerified(!!user?.email_confirmed_at);
    if (user) {
      const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", user.id);
      setIsAdmin(!!roles?.some((r) => r.role === "admin"));
    } else setIsAdmin(false);
  };

  useEffect(() => {
    refresh();
    const { data: sub } = supabase.auth.onAuthStateChange(() => refresh());
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <header className="relative z-30 mx-auto max-w-6xl px-4 py-4 sm:px-6 sm:py-6">
      <div className="flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3" onClick={() => setMobileOpen(false)}>
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-sm"><span className="font-arabic text-lg">م</span></div>
          <span className="font-display text-xl font-semibold text-foreground">Mithaq</span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <div className="relative" onMouseEnter={() => setLearnOpen(true)} onMouseLeave={() => setLearnOpen(false)}>
            <button className="flex min-h-10 items-center gap-1 hover:text-foreground" onClick={() => setLearnOpen((o) => !o)}>Learn <ChevronDown className="h-3.5 w-3.5" /></button>
            {learnOpen && <div className="absolute left-0 top-full z-10 w-56 rounded-xl border border-border bg-card p-2 shadow-[var(--shadow-elevated)]">{learnLinks.map((l) => <Link key={l.to} to={l.to} className="block rounded-lg px-3 py-2.5 text-sm text-foreground hover:bg-accent" activeProps={{ className: "block rounded-lg px-3 py-2.5 text-sm bg-accent text-foreground" }} onClick={() => setLearnOpen(false)}>{l.label}</Link>)}</div>}
          </div>
          {signedIn && !verified && <Link to="/verify-email" className="rounded-full bg-destructive/10 px-3 py-1.5 text-xs text-destructive">Verify email</Link>}
          {isAdmin && <Link to="/admin" className="rounded-full bg-primary/10 px-3 py-1.5 text-xs font-semibold text-primary">Admin</Link>}
          <Link to={signedIn ? "/dashboard" : "/auth"} className="rounded-full border border-border bg-card px-4 py-2 text-foreground shadow-sm hover:bg-accent">{signedIn ? "Dashboard" : "Sign in"}</Link>
        </nav>

        <button aria-label="Open navigation" aria-expanded={mobileOpen} onClick={() => setMobileOpen(!mobileOpen)} className="flex h-11 w-11 items-center justify-center rounded-full border border-border bg-card text-foreground shadow-sm md:hidden">{mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}</button>
      </div>

      {mobileOpen && (
        <nav className="mt-4 rounded-2xl border border-border bg-card p-3 shadow-[var(--shadow-elevated)] md:hidden">
          <p className="px-3 pb-2 pt-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Learn</p>
          {learnLinks.map((l) => <Link key={l.to} to={l.to} className="block min-h-11 rounded-xl px-3 py-3 text-sm font-medium text-foreground hover:bg-accent" onClick={() => setMobileOpen(false)}>{l.label}</Link>)}
          <div className="my-2 border-t border-border" />
          {signedIn && !verified && <Link to="/verify-email" className="block min-h-11 rounded-xl px-3 py-3 text-sm text-destructive" onClick={() => setMobileOpen(false)}>Verify your email</Link>}
          {isAdmin && <Link to="/admin" className="block min-h-11 rounded-xl px-3 py-3 text-sm font-semibold text-primary" onClick={() => setMobileOpen(false)}>Admin control</Link>}
          <Link to={signedIn ? "/dashboard" : "/auth"} className="mt-2 flex min-h-11 items-center justify-center rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground" onClick={() => setMobileOpen(false)}>{signedIn ? "Open dashboard" : "Sign in"}</Link>
        </nav>
      )}
    </header>
  );
}
