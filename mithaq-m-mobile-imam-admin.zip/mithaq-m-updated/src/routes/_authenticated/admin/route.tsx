import { createFileRoute, Link, Outlet, redirect } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { amIAdmin } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  ssr: false,
  beforeLoad: async () => {
    try {
      const res = await amIAdmin();
      if (!res.isAdmin) throw redirect({ to: "/dashboard" });
    } catch (e) {
      if (e && typeof e === "object" && "to" in e) throw e;
      throw redirect({ to: "/dashboard" });
    }
  },
  component: AdminLayout,
});

const links = [
  { to: "/admin", label: "Overview", exact: true },
  { to: "/admin/profiles", label: "Profiles" },
  { to: "/admin/new-profile", label: "New profile" },
  { to: "/admin/imams", label: "Imams" },
  { to: "/admin/imam-applications", label: "Imam applications" },
  { to: "/admin/memberships", label: "Memberships" },
  { to: "/admin/seed", label: "Seed data" },
] as const;

function AdminLayout() {
  const [now, setNow] = useState("");
  const [open, setOpen] = useState(false);
  useEffect(() => setNow(new Date().toLocaleString()), []);

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-card/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6 sm:py-4">
          <Link to="/admin" className="flex items-center gap-2" onClick={() => setOpen(false)}>
            <span className="rounded-md bg-primary px-2 py-1 text-[10px] font-semibold uppercase tracking-widest text-primary-foreground">Admin</span>
            <span className="font-display text-lg text-foreground">Mithaq control</span>
          </Link>
          <nav className="hidden items-center gap-4 text-sm lg:flex">
            {links.map((link) => <Link key={link.to} to={link.to} className="text-muted-foreground hover:text-foreground" activeOptions={link.exact ? { exact: true } : undefined} activeProps={{ className: "text-foreground font-semibold" }}>{link.label}</Link>)}
            <Link to="/dashboard" className="rounded-full border border-border px-3 py-2 hover:bg-accent">User view</Link>
          </nav>
          <button aria-label="Toggle admin navigation" aria-expanded={open} onClick={() => setOpen(!open)} className="flex h-11 w-11 items-center justify-center rounded-full border border-border lg:hidden">{open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}</button>
        </div>
        {open && <nav className="mx-4 mb-3 grid rounded-2xl border border-border bg-card p-2 shadow-[var(--shadow-elevated)] sm:mx-6 lg:hidden">{links.map((link) => <Link key={link.to} to={link.to} onClick={() => setOpen(false)} className="min-h-11 rounded-xl px-3 py-3 text-sm text-muted-foreground hover:bg-accent hover:text-foreground" activeOptions={link.exact ? { exact: true } : undefined} activeProps={{ className: "bg-accent text-foreground font-semibold" }}>{link.label}</Link>)}<Link to="/dashboard" onClick={() => setOpen(false)} className="mt-1 flex min-h-11 items-center justify-center rounded-xl bg-primary px-3 py-3 text-sm font-semibold text-primary-foreground">Open user view</Link></nav>}
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
        <Outlet />
        <p className="mt-8 text-right text-[10px] text-muted-foreground">{now}</p>
      </main>
    </div>
  );
}
