import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Eye, EyeOff, KeyRound, Pencil, Plus, ShieldCheck, Trash2, UserRoundPlus } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
  createImam,
  createImamAccountAdmin,
  deleteImam,
  listImamAccountsAdmin,
  resetImamPasswordAdmin,
  seedExampleImams,
  updateImam,
  ADMIN_UK_CITIES,
} from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin/imams")({
  head: () => ({ meta: [{ title: "Imams — Admin" }, { name: "robots", content: "noindex" }] }),
  component: ImamsAdmin,
});

type Imam = Awaited<ReturnType<typeof listImamAccountsAdmin>>[number];

const emptyImam = {
  name: "", title: "Imam", mosque: "", city: ADMIN_UK_CITIES[0], postcode: "",
  phone: "", email: "", website: "", languages: "", notes: "",
};

function ImamsAdmin() {
  const fetchAll = useServerFn(listImamAccountsAdmin);
  const doCreate = useServerFn(createImam);
  const doUpdate = useServerFn(updateImam);
  const doDelete = useServerFn(deleteImam);
  const doSeed = useServerFn(seedExampleImams);
  const createAccount = useServerFn(createImamAccountAdmin);
  const resetPassword = useServerFn(resetImamPasswordAdmin);

  const [rows, setRows] = useState<Imam[] | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [editing, setEditing] = useState<Imam | null>(null);
  const [form, setForm] = useState(emptyImam);
  const [accountFor, setAccountFor] = useState<Imam | null>(null);
  const [accountForm, setAccountForm] = useState({ email: "", password: "", radius_km: 40 });
  const [resetFor, setResetFor] = useState<Imam | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = () => fetchAll().then(setRows);
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  const summary = useMemo(() => ({
    total: rows?.length ?? 0,
    active: rows?.filter((r) => r.account?.active).length ?? 0,
    withoutLogin: rows?.filter((r) => !r.account).length ?? 0,
  }), [rows]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    const payload = {
      name: form.name.trim(), title: form.title.trim() || null, mosque: form.mosque.trim() || null,
      city: form.city.trim(), postcode: form.postcode.trim() || null, phone: form.phone.trim() || null,
      email: form.email.trim() || null, website: form.website.trim() || null,
      languages: form.languages.split(",").map((s) => s.trim()).filter(Boolean), notes: form.notes.trim() || null,
    };
    try {
      setBusy(true);
      if (editing) {
        await doUpdate({ data: { id: editing.id, ...payload } });
        setMsg("Imam details updated.");
      } else {
        await doCreate({ data: payload });
        setMsg("Imam added to the directory. You can now create their login below.");
      }
      setForm(emptyImam);
      setEditing(null);
      await load();
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "Failed");
    } finally { setBusy(false); }
  };

  const edit = (r: Imam) => {
    setEditing(r);
    setForm({
      name: r.name ?? "", title: r.title ?? "", mosque: r.mosque ?? "", city: r.city ?? ADMIN_UK_CITIES[0],
      postcode: r.postcode ?? "", phone: r.phone ?? "", email: r.email ?? "", website: r.website ?? "",
      languages: (r.languages ?? []).join(", "), notes: r.notes ?? "",
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this imam directory entry? Delete or deactivate their login first if they have an account.")) return;
    try { await doDelete({ data: { id } }); await load(); }
    catch (err) { setMsg(err instanceof Error ? err.message : "Could not delete imam"); }
  };

  const openAccount = (imam: Imam) => {
    setAccountFor(imam);
    setResetFor(null);
    setAccountForm({ email: imam.email ?? "", password: "", radius_km: 40 });
    setShowPassword(false);
  };

  const submitAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accountFor) return;
    try {
      setBusy(true);
      await createAccount({ data: { imam_id: accountFor.id, ...accountForm } });
      setMsg(`Login created for ${accountFor.name}. Give the temporary password to the imam securely.`);
      setAccountFor(null);
      await load();
    } catch (err) { setMsg(err instanceof Error ? err.message : "Could not create account"); }
    finally { setBusy(false); }
  };

  const submitReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetFor?.account) return;
    try {
      setBusy(true);
      await resetPassword({ data: { user_id: resetFor.account.user_id, password: newPassword } });
      setMsg(`Password reset for ${resetFor.name}. The old password can no longer be used.`);
      setResetFor(null);
      setNewPassword("");
    } catch (err) { setMsg(err instanceof Error ? err.message : "Could not reset password"); }
    finally { setBusy(false); }
  };

  const seed = async () => {
    const r = await doSeed();
    setMsg(`Seeded ${r.inserted} example imam(s); ${r.skipped} already existed.`);
    load();
  };

  return (
    <div className="space-y-6 sm:space-y-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">People and access</p>
          <h1 className="mt-1 text-3xl text-foreground sm:text-4xl">Imams</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
            Manage directory details, create secure imam logins, and reset temporary passwords.
          </p>
        </div>
        <button onClick={seed} className="min-h-11 rounded-full border border-border bg-card px-4 text-sm font-medium shadow-sm hover:bg-accent">
          Add example imams
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Directory profiles" value={summary.total} />
        <Stat label="Active logins" value={summary.active} />
        <Stat label="Need a login" value={summary.withoutLogin} />
      </div>

      {msg && <div className="rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-sm text-foreground">{msg}</div>}

      <form onSubmit={submit} className="grid gap-4 rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-soft)] sm:p-6 md:grid-cols-2">
        <div className="md:col-span-2 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-xl text-foreground">{editing ? `Edit ${editing.name}` : "Add an imam"}</h2>
            <p className="mt-1 text-xs text-muted-foreground">Directory information is public. Login details are created separately.</p>
          </div>
          <div className="rounded-full bg-primary/10 p-2 text-primary"><Plus className="h-4 w-4" /></div>
        </div>
        <Field label="Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
        <Field label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} />
        <Field label="Mosque" value={form.mosque} onChange={(v) => setForm({ ...form, mosque: v })} />
        <label className="block"><Label>City</Label><select value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="form-control">{ADMIN_UK_CITIES.map((c) => <option key={c}>{c}</option>)}</select></label>
        <Field label="Postcode" value={form.postcode} onChange={(v) => setForm({ ...form, postcode: v })} />
        <Field label="Phone" type="tel" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} />
        <Field label="Public email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
        <Field label="Website" type="url" value={form.website} onChange={(v) => setForm({ ...form, website: v })} />
        <Field label="Languages (comma-separated)" value={form.languages} onChange={(v) => setForm({ ...form, languages: v })} />
        <label className="md:col-span-2 block"><Label>Private admin notes</Label><textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={3} className="form-control resize-y" /></label>
        <div className="md:col-span-2 flex flex-col gap-2 sm:flex-row">
          <button disabled={busy} className="min-h-11 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60">{editing ? "Save changes" : "Add imam"}</button>
          {editing && <button type="button" onClick={() => { setEditing(null); setForm(emptyImam); }} className="min-h-11 rounded-full border border-border px-4 text-sm hover:bg-accent">Cancel</button>}
        </div>
      </form>

      {(accountFor || resetFor) && (
        <section className="rounded-2xl border border-primary/20 bg-card p-4 shadow-[var(--shadow-elevated)] sm:p-6">
          {accountFor && (
            <form onSubmit={submitAccount} className="space-y-4">
              <div className="flex items-start justify-between gap-4"><div><h2 className="text-xl">Create login for {accountFor.name}</h2><p className="mt-1 text-sm text-muted-foreground">The imam will sign in with this email and temporary password.</p></div><ShieldCheck className="h-6 w-6 text-primary" /></div>
              <div className="grid gap-4 md:grid-cols-3">
                <Field label="Login email" type="email" value={accountForm.email} onChange={(v) => setAccountForm({ ...accountForm, email: v })} required />
                <PasswordField label="Temporary password" value={accountForm.password} onChange={(v) => setAccountForm({ ...accountForm, password: v })} show={showPassword} toggle={() => setShowPassword(!showPassword)} />
                <label><Label>Coverage radius (km)</Label><input type="number" min={5} max={300} value={accountForm.radius_km} onChange={(e) => setAccountForm({ ...accountForm, radius_km: Number(e.target.value) })} className="form-control" /></label>
              </div>
              <p className="text-xs text-muted-foreground">Use at least 8 characters. Send it privately and ask the imam to replace it after signing in.</p>
              <div className="flex flex-col gap-2 sm:flex-row"><button disabled={busy} className="min-h-11 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground">Create imam login</button><button type="button" onClick={() => setAccountFor(null)} className="min-h-11 rounded-full border border-border px-4 text-sm">Cancel</button></div>
            </form>
          )}
          {resetFor?.account && (
            <form onSubmit={submitReset} className="space-y-4">
              <div><h2 className="text-xl">Reset password for {resetFor.name}</h2><p className="mt-1 text-sm text-muted-foreground">You cannot view the existing password. Setting a new one immediately replaces it.</p></div>
              <div className="max-w-md"><PasswordField label="New temporary password" value={newPassword} onChange={setNewPassword} show={showPassword} toggle={() => setShowPassword(!showPassword)} /></div>
              <div className="flex flex-col gap-2 sm:flex-row"><button disabled={busy} className="min-h-11 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground">Reset password</button><button type="button" onClick={() => setResetFor(null)} className="min-h-11 rounded-full border border-border px-4 text-sm">Cancel</button></div>
            </form>
          )}
        </section>
      )}

      <section className="space-y-3">
        <div className="flex items-center justify-between"><h2 className="text-2xl">Directory and account access</h2><span className="text-xs text-muted-foreground">{rows === null ? "Loading…" : `${rows.length} total`}</span></div>
        <div className="grid gap-3 md:hidden">
          {(rows ?? []).map((r) => <ImamCard key={r.id} imam={r} onEdit={() => edit(r)} onDelete={() => remove(r.id)} onCreateAccount={() => openAccount(r)} onReset={() => { setResetFor(r); setAccountFor(null); setShowPassword(false); }} />)}
        </div>
        <div className="hidden overflow-x-auto rounded-2xl border border-border bg-card shadow-[var(--shadow-soft)] md:block">
          <table className="w-full min-w-[900px] text-sm"><thead className="bg-muted/70 text-left text-xs uppercase tracking-widest text-muted-foreground"><tr><th className="px-4 py-3">Imam</th><th className="px-4 py-3">Location</th><th className="px-4 py-3">Login</th><th className="px-4 py-3">Activity</th><th className="px-4 py-3 text-right">Actions</th></tr></thead>
            <tbody className="divide-y divide-border">{(rows ?? []).map((r) => <tr key={r.id} className="hover:bg-accent/30"><td className="px-4 py-4"><div className="font-semibold">{r.name}</div><div className="text-xs text-muted-foreground">{r.mosque ?? r.title ?? "Imam"}</div></td><td className="px-4 py-4"><div>{r.city}</div><div className="text-xs text-muted-foreground">{r.postcode ?? "No postcode"}</div></td><td className="px-4 py-4">{r.account ? <><div className="font-medium">{r.account.email}</div><div className="mt-1"><Status active={r.account.active} /></div></> : <span className="text-muted-foreground">No login yet</span>}</td><td className="px-4 py-4 text-xs text-muted-foreground">{r.account?.last_sign_in_at ? `Last sign-in ${new Date(r.account.last_sign_in_at).toLocaleDateString()}` : "No sign-in recorded"}</td><td className="px-4 py-4"><div className="flex justify-end gap-2"><Action title="Edit" onClick={() => edit(r)}><Pencil /></Action>{r.account ? <Action title="Reset password" onClick={() => { setResetFor(r); setAccountFor(null); }}><KeyRound /></Action> : <Action title="Create login" onClick={() => openAccount(r)}><UserRoundPlus /></Action>}<Action danger title="Delete" onClick={() => remove(r.id)}><Trash2 /></Action></div></td></tr>)}</tbody>
          </table>
        </div>
        {rows?.length === 0 && <div className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No imams yet. Add one above.</div>}
      </section>
    </div>
  );
}

function ImamCard({ imam, onEdit, onDelete, onCreateAccount, onReset }: { imam: Imam; onEdit: () => void; onDelete: () => void; onCreateAccount: () => void; onReset: () => void }) {
  return <article className="rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-soft)]"><div className="flex items-start justify-between gap-3"><div><h3 className="text-xl">{imam.name}</h3><p className="text-sm text-muted-foreground">{imam.mosque ?? imam.title ?? "Imam"}</p></div>{imam.account ? <Status active={imam.account.active} /> : <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] text-muted-foreground">No login</span>}</div><div className="mt-4 grid grid-cols-2 gap-3 text-sm"><div><p className="text-xs text-muted-foreground">Location</p><p>{imam.city}{imam.postcode ? `, ${imam.postcode}` : ""}</p></div><div><p className="text-xs text-muted-foreground">Login email</p><p className="truncate">{imam.account?.email ?? "Not created"}</p></div></div><div className="mt-4 grid grid-cols-2 gap-2"><button onClick={onEdit} className="min-h-11 rounded-xl border border-border text-sm font-medium"><Pencil className="mr-2 inline h-4 w-4" />Edit</button><button onClick={imam.account ? onReset : onCreateAccount} className="min-h-11 rounded-xl bg-primary text-sm font-medium text-primary-foreground">{imam.account ? <KeyRound className="mr-2 inline h-4 w-4" /> : <UserRoundPlus className="mr-2 inline h-4 w-4" />}{imam.account ? "Reset password" : "Create login"}</button><button onClick={onDelete} className="col-span-2 min-h-11 rounded-xl text-sm text-destructive hover:bg-destructive/10"><Trash2 className="mr-2 inline h-4 w-4" />Delete directory entry</button></div></article>;
}
function Status({ active }: { active: boolean }) { return <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold ${active ? "bg-emerald-500/10 text-emerald-700" : "bg-muted text-muted-foreground"}`}>{active ? "Active login" : "Inactive"}</span>; }
function Stat({ label, value }: { label: string; value: number }) { return <div className="rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-soft)]"><p className="text-2xl font-semibold text-foreground">{value}</p><p className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{label}</p></div>; }
function Label({ children }: { children: React.ReactNode }) { return <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">{children}</span>; }
function Field({ label, value, onChange, required, type = "text" }: { label: string; value: string; onChange: (v: string) => void; required?: boolean; type?: string }) { return <label className="block"><Label>{label}</Label><input type={type} required={required} value={value} onChange={(e) => onChange(e.target.value)} className="form-control" /></label>; }
function PasswordField({ label, value, onChange, show, toggle }: { label: string; value: string; onChange: (v: string) => void; show: boolean; toggle: () => void }) { return <label className="block"><Label>{label}</Label><div className="relative"><input required minLength={8} type={show ? "text" : "password"} value={value} onChange={(e) => onChange(e.target.value)} className="form-control pr-12" /><button type="button" aria-label={show ? "Hide password" : "Show password"} onClick={toggle} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-muted-foreground hover:bg-accent">{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></div></label>; }
function Action({ title, onClick, danger, children }: { title: string; onClick: () => void; danger?: boolean; children: React.ReactElement<{ className?: string }> }) { return <button aria-label={title} title={title} onClick={onClick} className={`rounded-xl border p-2.5 hover:bg-accent ${danger ? "border-destructive/30 text-destructive" : "border-border"}`}>{children}</button>; }
