# Vercel deployment settings

Add these environment variables in Vercel for Production and Preview, then redeploy:

- SUPABASE_URL
- SUPABASE_PUBLISHABLE_KEY
- SUPABASE_SERVICE_ROLE_KEY
- VITE_SUPABASE_URL
- VITE_SUPABASE_PUBLISHABLE_KEY
- VITE_SUPABASE_PROJECT_ID
- STRIPE_SECRET_KEY (recommended) or STRIPE_RESTRICTED_API_KEY
- STRIPE_MONTHLY_PRICE_ID
- STRIPE_YEARLY_PRICE_ID
- STRIPE_WEBHOOK_SECRET

Create monthly and yearly recurring Prices in Stripe and copy their `price_...` IDs into the two Price ID variables. This avoids requiring the API key to create Products and Prices dynamically.

Configure the Stripe webhook endpoint as:

`https://mithaq-m.vercel.app/api/public/stripe-webhook`

Subscribe to:

- checkout.session.completed
- customer.subscription.updated
- customer.subscription.deleted

Copy the webhook signing secret beginning with `whsec_` into STRIPE_WEBHOOK_SECRET.
